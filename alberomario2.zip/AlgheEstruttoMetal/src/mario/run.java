package mario;
import java.util.HashMap;

public class run {
	public static void main(String[] args) throws RootAlreadyExistsException, OverWriteException, ChildDoesntExistException {
		
		HashMap<String,Integer> pocoyo=new HashMap<>();
		Integer cacca=pocoyo.get("santaclaus");
		System.out.println(cacca);
		AlberoMario comunismo = new AlberoMario(3);
		NodoMario tmp;
		comunismo.insertRoot("GIGIONE");
		comunismo.replaceRoot("Berlusca, Cavaliere", 0);

		tmp=comunismo.getRoot();
		comunismo.insertNode(tmp,"RomanoProdi, difensore della Patria", 1);
		tmp=comunismo.getRoot().getChild(0);

		
		comunismo.insertNode(tmp,"DANTE",0);
		comunismo.insertNode(tmp,"BOCCACCIO",1);
		comunismo.insertNode(tmp,"DIPRE'",2);
		
		
		comunismo.insertNode(tmp.getChild(1), "Bucchin", 0);
		comunismo.insertNode(tmp.getChild(1), "dituma", 1);
		
		
		tmp=comunismo.getRoot().getChild(1);

		comunismo.insertNode(tmp, "Peroni Mista Azzurra", 0);
		comunismo.insertNode(tmp, "Barbie Brigate Rosse", 1);
		comunismo.insertNode(tmp, "Super Mario Rave", 2);
		
		comunismo.insertNode(tmp.getChild(1),"Spettro del Comunismo",0);
		
		System.out.println(comunismo);
		
		AlberoMario fascismo=new AlberoMario(2);
		fascismo.depthViewVisualizer();
	}		
}
