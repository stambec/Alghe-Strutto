package mario;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;






public class AlberoMario{
	private NodoMario root;
	private int m;				//m-arity
	private int totalNodes=0;
	// Nota: questa implementazione NON prevede l'estensione esplicita dell'albero m_ario.
	// ovverosia, apparterranno all'albero soltanto i nodi interni, mentre quelli esterni, fittizzi,
	// potranno essere dedotti implicitamente, e non sono generalmente utilizzati.
	// Pertanto, ogni riferimento a nodi figli è da intendersi come diretto a nodi interni.
	
	
	
	
	
	
	public AlberoMario(int m){			
		this.m=m;			
	}
	@Override
	public String toString() {
		if(this.root==null)	return "Albero m-ario vuoto di arietà "+this.m+".";
		else {
			String out=" Albero m-ario di arietà "+this.m+", altezza "+getHeight()+" ed "+getTotalNodes()+" nodi in totale.\n Lista nodi (Visualizzazione per livelli):\n";
			for(String nodoInfo : DFS() )	out+="    -"+nodoInfo+"\n";
			out+="BFS\n";
			for(String nodoInfo : BFS() )	out+="    -"+nodoInfo+"\n";
			return out;
		}
	}

	

	
	
		
	public boolean isEmpty(){
		return (root==null);
	}
	public int getTotalNodes(){
		return totalNodes; //alternativa low cost
	}
	public int getTotalLeaves(){
		if(this.isEmpty()) 		return 0;
		int counter=0;
		NodoMario tmp;
		Queue<NodoMario> frangia=new LinkedList<NodoMario>();
		frangia.add(root);
		while(!frangia.isEmpty()) {
			tmp=frangia.remove();
			if(tmp.isLeaf())	counter++;
			else				frangia.addAll(tmp.getChildren());	
		}
		return counter;
	}
	public int getHeight() {						//conteggio dei livelli.
		if(isEmpty()) 			return 0;
		int counter=0;
		ArrayList<NodoMario>    fringe= new ArrayList<>(this.root.getChildren());	//inizializzazione frangia con i nodi del primo livello.
		ArrayList<NodoMario> nextLevel= new ArrayList<NodoMario>();					//adibito a contenere i nodi del seguente livello.
		while ( !fringe.isEmpty() )
		{
			counter++;
			for(NodoMario node : fringe)	nextLevel.addAll(node.getChildren());	//caricamento del livello seguente.
			fringe.clear();
			fringe.addAll(nextLevel);
			nextLevel.clear();			
		}
		return counter;
	}
	
	
	
	
	
	public NodoMario getRoot(){
		return root;	
	}
	public void insertRoot(String info) throws RootAlreadyExistsException{
		if (!isEmpty())	throw new RootAlreadyExistsException();
		this.root=new NodoMario(info);
		totalNodes++;
	}
	public void insertNode(NodoMario father,String childInfo,int index) throws OverWriteException{
		if (index>=this.m || index<0)		throw new IllegalArgumentException("Attenzione! Un indice non può essere negativo od inferiore alla m-arietà dell'albero ("+this.m+").");
		father.setChild(new NodoMario(childInfo),index);
		totalNodes++;
	}
	public void replaceRoot(String newRootInfo,int index) throws OverWriteException{
		if (index>=this.m || index<0)		throw new IllegalArgumentException("Attenzione! Un indice non può essere negativo od inferiore alla m-arietà dell'albero ("+this.m+").");
		NodoMario oldRoot=this.root;
		this.root=new NodoMario(newRootInfo);
		this.root.setChild(oldRoot, index);
		totalNodes++;
	}

	
	
	
	
	
	public int getNodeHeight(NodoMario query){
		int counter=0;
		while(query.hasFather()){
			query=query.getFather();
			counter++;
		}
		return counter;
	}
	public NodoMario getNodeFather(NodoMario child){
		return child.getFather(); //ritorna null se non lo possiede (es. root)
	}
	public int getNodeTotalInnerChildren(NodoMario node) { //Nota: essendo questo un comando dedicato all'utente, è esplicitato che si tratti di nodi interni.
		return node.getTotalChildren();
	}
	public String getNodeInfo(NodoMario node) {
		return node.get();
	}
	public void changeNodeInfo(NodoMario node, String newInfo) {
		node.set(newInfo);
	}

	
	
	
	
	
	public ArrayList<NodoMario> getInternalChildren(NodoMario query) {	   
		return query.getChildren();
	}
	public ArrayList<String> getInternalChildrenInfo(NodoMario query){ 
		return query.getChildrenInfo();
	}

		
	


	
	public void depthViewVisualizer() {
		for(String nodeInfo : DFS())		System.out.println(" -"+nodeInfo);
	}
	public void broadViewVisualizer() {
		for (String nodeInfo : BFS())		System.out.println(" -"+nodeInfo);
	}
	
	
	
	
	
	
	public ArrayList<String> DFS(){	
		if(isEmpty())		return new ArrayList<>();
		else				return DFShelper(new ArrayList<String>(),this.root);	//inizializzazione con array
	}
	private ArrayList<String> DFShelper(ArrayList<String> temp,NodoMario query){		//Ricorsione
		temp.add(query.get());
		for (NodoMario child : query.getChildren())		DFShelper(temp,child);
		return temp;
	}
	
	
	
	
	
	
	public ArrayList<String> BFS(){
		if (isEmpty()) 		 return new ArrayList<>();
		int index=0;
		ArrayList<NodoMario> array= new ArrayList<>();
		NodoMario currentNode;
		array.add(root);
		while(index<this.totalNodes)
		{
			currentNode=array.get(index++);
			for (NodoMario child : currentNode.getChildren())	array.add(child);
		}
		ArrayList<String> result= new ArrayList<>();				
		for( NodoMario node : array)							result.add(node.get());	//conversione Array nodi > Array stringhe	
		return result;
	}
}