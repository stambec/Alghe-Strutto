package mario;

public class RootAlreadyExistingException extends Exception {

}
