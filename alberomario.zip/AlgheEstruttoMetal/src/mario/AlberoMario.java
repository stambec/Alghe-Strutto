package mario;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;






public class AlberoMario{
	private NodoMario root;
	private int m;				//m-arity
	private int totalNodes=0;
	// Nota: questa implementazione NON prevede l'estensione esplicita dell'albero m_ario.
	// ovverosia, apparterranno all'albero soltanto i nodi interni, mentre quelli esterni, fittizzi,
	// potranno essere dedotti implicitamente, e non sono generalmente utilizzati.
	// Pertanto, ogni riferimento a nodi figli è da intendersi come diretto a nodi interni.
	
	
	
	
	
	
	public AlberoMario(int m){			
		this.m=m;			
	}
	@Override
	public String toString() {
		if(this.root==null)	return "Albero m-ario vuoto di arietà "+this.m+".";
		else {
			String out=" Albero m-ario di arietà "+this.m+", altezza "+getHeight()+" ed "+getTotalNodes()+" nodi in totale.\n Lista nodi (Visualizzazione per livelli):\n";
			for(String nodoInfo : DFS() )	out+="    -"+nodoInfo+"\n";
			return out;
		}
	}

	

	
	
		
	public boolean isEmpty(){
		return (root==null);
	}
	public int getTotalNodes(){
		return totalNodes; //alternativa low cost
	}
	public int getTotalLeaves(){
		if(this.isEmpty()) return 0;
		int counter=0;
		NodoMario tmp;
		Queue<NodoMario> frangia=new LinkedList<NodoMario>();
		frangia.add(root);
		while(!frangia.isEmpty()) {
			tmp=frangia.remove();
			if(tmp.isLeaf())	counter++;
			else				frangia.addAll(tmp.getChildren());	
		}
		return counter;
	}
/*	public int getHeight1() {						//conteggio dei livelli.
		if(this.isEmpty()) return 0;
		int counterLvl=0;
		ArrayList<NodoMario> frangia=new ArrayList<>(this.root.getChildren());	//inizializzazione con i nodi del primo livello.
		Queue<NodoMario> nextlevel=new LinkedList<NodoMario>();					//adibito a contenere i nodi del seguente livello.
		while ( !frangia.isEmpty() )
		{
			for(NodoMario node : frangia)	nextlevel.addAll(node.getChildren());	//caricamento del livello seguente.
			frangia.clear();
			counterLvl++;
			while( !nextlevel.isEmpty() )		frangia.add(nextlevel.remove());			
		}
		return counterLvl;
	}*/
	public int getHeight() {						//conteggio dei livelli.
		if(this.isEmpty()) return 0;
		int counterLvl=0;
		ArrayList<NodoMario> frangia=new ArrayList<>(this.root.getChildren());	//inizializzazione con i nodi del primo livello.
		ArrayList<NodoMario> nextlevel=new ArrayList<NodoMario>();				//adibito a contenere i nodi del seguente livello.
		while ( !frangia.isEmpty() )
		{
			counterLvl++;
			for(NodoMario node : frangia)	nextlevel.addAll(node.getChildren());	//caricamento del livello seguente.
			frangia.clear();
			frangia.addAll(nextlevel);
			nextlevel.clear();			
		}
		return counterLvl;
	}
	
	
	
	
	
	public NodoMario getRoot(){
		return root;	
	}
	public void insertRoot(String info) throws RootAlreadyExistsException{
		if (!isEmpty())	throw new RootAlreadyExistsException();
		this.root=new NodoMario(info);
		totalNodes++;
	}
	public void insertNode(NodoMario father,String childInfo,int index) throws OverWriteException{
		if (index>=this.m || index<0)		throw new IllegalArgumentException("Attenzione! Un indice non può essere negativo od inferiore alla m-arietà dell'albero ("+this.m+").");
		father.setChild(new NodoMario(childInfo),index);
		totalNodes++;
	}
	public void replaceRoot(String newRootInfo,int index) throws OverWriteException{
		if (index>=this.m || index<0)		throw new IllegalArgumentException("Attenzione! Un indice non può essere negativo od inferiore alla m-arietà dell'albero ("+this.m+").");
		NodoMario oldRoot=this.root;
		this.root=new NodoMario(newRootInfo);
		this.root.setChild(oldRoot, index);
		totalNodes++;
	}

	
	
	
	
	
	public int getNodeHeight(NodoMario query){
		int counter=0;
		while(query.hasFather()){
			query=query.getFather();
			counter++;
		}
		return counter;
	}
	public NodoMario getNodeFather(NodoMario child){
		return child.getFather(); //ritorna null se non lo possiede (es. root)
	}
	public int getNodeTotalInnerChildren(NodoMario node) { //Nota: essendo questo un comando dedicato all'utente, è esplicitato che si tratti di nodi interni.
		return node.getTotalChildren();
	}
	public String getNodeInfo(NodoMario node) {
		return node.get();
	}
	public void changeNodeInfo(NodoMario node, String newInfo) {
		node.set(newInfo);
	}

	
	
	
	
	
	public ArrayList<NodoMario> getInternalChildren(NodoMario query) {	   
		return query.getChildren();
	}
	public ArrayList<String> getInternalChildrenInfo(NodoMario query){ 
		return query.getChildrenInfo();
	}

		
	


	
	public void depthViewVisualizer() {
		for(String element : DFS())		System.out.println(" -"+element);
	}
	public void broadViewVisualizer() {
		for (String element : BFS())		System.out.println(" -"+element);
	}
	
	
	
	
	
	
	public ArrayList<String> DFS(){	
		if(this.root==null)		return null;
		else					return DFShelper(new ArrayList<String>(),this.root);
	}
	private ArrayList<String> DFShelper(ArrayList<String> temp,NodoMario query){
		temp.add(query.get());
		for (NodoMario child : query.getChildren())		DFShelper(temp,child);
		return temp;
	}
	
	
	
	
	
	
	public ArrayList<String> BFS(){
		if (isEmpty()) return null;
		int index=0;
		ArrayList<NodoMario> flush=new ArrayList<>();
		flush.add(this.root);
		while(index<this.totalNodes){
			for (NodoMario child : flush.get(index++).getChildren())	flush.add(child);
		}
		ArrayList<String> result= new ArrayList<>();
		for( NodoMario node : flush)	result.add(node.get());
		return result;
	}
}