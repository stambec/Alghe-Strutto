package mario;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.concurrent.TimeUnit;


//immediati:
//		inserire radice da info 							 I
//		restituire info di nodo 							IX
//		cambiare info di nodo 								 X
//		restituire radice 									XI

//da pensarci:
//		Inserire V figlio di U in indice ix 				II
//		restituire numero nodi 								VI
//		restituire il padre di nodo 					   XII
//		restituire numero foglie albero					  XIII
//		restituire altezza albero						   XIV
//		restituire livello nodo     						XV

//Algo easyyyss:
//		Da nodo interno, restituire figli nodi interni	   VII
//		Da nodo interno, restituire info figli interni 	  VIII

//Deep Algos:
//		Inserire nuova radice tc vecchia figlia in ix      III
//		Depth View (anticipata)								IV
//		Broad View											 V

import java.util.Queue;
public class AlberoMario{
	private NodoMario root;
	private int m;				//m-arity
	private int totalNodes=0;
	// Nota: questa implementazione NON prevede l'estensione esplicita dell'albero m_ario.
	// ovvero, apparterranno all'albero soltanto i nodi interni, mentre quelli esterni, fittizzi,
	// potranno essere dedotti implicitamente, e non sono generalmente utilizzati.
	// Pertanto, ogni riferimento a nodi figli è da intendersi come diretto a nodi interni.
	
	
	public AlberoMario(int m){			
		this.m=m;			
	}
	@Override
	public String toString() {
		if(this.root==null)	return "Albero vuoto (di"+this.m+").";
		else {
			return "Albero m-ario (di m="+this.m+"). Alto: "+getHeight()+"   lista nodi:";
		}
	}
	public void debug() {		//serve solo per debug
		System.out.println("---");
		System.out.println(toString());
		System.out.println("DEEPVIEW");
		depthView();
		System.out.println("BROADVIEW");
		broadView();
		System.out.println("---\n");
	}
	

	
	
	
	public boolean isEmpty(){
		return (root==null);
	}
	public int getTotalNodes(){					// VI
		return totalNodes; //alternativa low cost
	}
	public int getTotalLeaves(){
		if(this.isEmpty()) return 0;
		int counter=0;
		NodoMario tmp;
		Queue<NodoMario> frangia=new LinkedList<NodoMario>();
		frangia.add(root);
		while(!frangia.isEmpty()) {
			tmp=frangia.remove();
			if(tmp.isLeaf())	counter++;
			else				frangia.addAll(tmp.getChildren());	
		}
		return counter;
	}
	public int getHeight() {
		if(this.isEmpty()) return 0;
		int counterLvl=0;
		ArrayList<NodoMario> frangia=new ArrayList<>();
		frangia.addAll(this.root.getChildren());
		Queue<NodoMario> nextlevel=new LinkedList<NodoMario>();
		while (!frangia.isEmpty()) {
			for(NodoMario node : frangia)	nextlevel.addAll(node.getChildren());
			frangia.clear();
			counterLvl++;
			while(!nextlevel.isEmpty())		frangia.add(nextlevel.remove());			
		}
		return counterLvl;
	}

	
	
	
	
	
	public NodoMario getRoot(){					// XI
		return root;	
	}
	public void insertRoot(String info) throws RootAlreadyExistsException{
		if (!isEmpty())	throw new RootAlreadyExistsException();
		this.root=new NodoMario(info);
		totalNodes++;
	}
	public void insertNode(NodoMario father,String childInfo,int index) throws OverWriteException{	// II
		if (index>=this.m || index<0)		throw new IllegalArgumentException("Attenzione! Un indice non può essere negativo od inferiore alla m-arietà dell'albero ("+this.m+").");
		father.setChild(new NodoMario(childInfo),index);
		totalNodes++;
	}
	public void replaceRoot(String newRootInfo,int index) throws OverWriteException{
		if (index>=this.m || index<0)		throw new IllegalArgumentException("Attenzione! Un indice non può essere negativo od inferiore alla m-arietà dell'albero ("+this.m+").");
		NodoMario oldRoot=this.root;
		this.root=new NodoMario(newRootInfo);
		this.root.setChild(oldRoot, index);
	}

	
	
	
	
	public int getNodeHeight(NodoMario query){					// XV
		int counter=0;
		while(query.hasFather()){
			query=query.getFather();
			counter++;
		}
		return counter;
	}
	public NodoMario getNodeFather(NodoMario child){
		return child.getFather(); //ritorna null se non lo possiede
	}
	public int getNodeTotalInnerChildren(NodoMario node) {
		return node.getTotalChildren();
	}
	public String getNodeInfo(NodoMario node) {							// IX
		return node.get();							//ridondante
	}
	public void changeNodeInfo(NodoMario node, String newInfo) {		// X
		node.set(newInfo);							//ridondante
	}

	
	
	
	
	public ArrayList<NodoMario> getInternalChildren(NodoMario query) {	   // VII
		return query.getChildren();
	}
	public ArrayList<String> getInternalChildrenInfo(NodoMario query){ 	   // VIII
		return query.getChildrenInfo();
	}

		
	
	
	
	public void depthView(){	
		if(this.root==null)	return;
		depthViewer(this.root);
	}
	private void depthViewer(NodoMario query){
		System.out.println(query);
		for (NodoMario child : query.getChildren())	depthViewer(child);
	}
	
	
	
	
	
	public void broadView() {						// V
		if (isEmpty()) return;
		System.out.println("BROADVIEW");
		Queue<NodoMario> flush=new LinkedList<>();
		NodoMario tmp;
		flush.add(this.root);
		while(!flush.isEmpty()){
			tmp=flush.remove();
			System.out.println(tmp);
			for (NodoMario child : tmp.getChildren()){
				flush.add(child);
			}
		}

	}
}