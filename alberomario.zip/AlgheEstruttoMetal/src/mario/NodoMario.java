package mario;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class NodoMario{
	private HashMap<Integer,NodoMario> childs;
	private String info;
	private NodoMario father;

	
	
	
	
	public NodoMario(String info){
		this.info=info;
		this.childs=new HashMap<>();
	}
	public NodoMario(String info,NodoMario father){
		this(info);
		this.father=father;
	}
	@Override
	public String toString() {
		if(hasFather())	return "  -nodo '"+this.get()+"'\t(figlio di: "+father.get()+") ["+getTotalChildren()+" figli]";
		else			return "  -nodo '"+this.get()+"' ["+getTotalChildren()+" figli]";
	}
	public void debug() {			//solo per debug	
		System.out.println(toString());
	}
	
	
	
	
	
	
	public String get(){				// IX
		return info;
	}
	public void set(String info){		// X
		this.info=info;
	}
	public NodoMario asSingleNode() {				//restituisce un nodo identico, ma senza puntatori (aka,
		return new NodoMario(this.get());	// 									 non un sottoalbero)
	}
	
	
	
	
	
	public boolean isLeaf() {
		if(getTotalChildren()==0)	return true;
		return false;
	}
	public boolean hasFather(){
		return (father!=null);
	}
	public NodoMario getFather(){
		return father;			//returns null if root/unfathered
	}
	public void setFather(NodoMario father) {
		this.father=father;
	}
	public void setChild(NodoMario newChild, int index) throws OverWriteException {
		if (childs.get(index)!=null)	throw new OverWriteException(childs.get(index),newChild);
		this.childs.put(index,newChild);
		newChild.setFather(this);
	}
	public NodoMario getChild(int index) throws ChildDoesntExistException{
		if(childs.get(index)==null)throw new ChildDoesntExistException(this,index);
		return childs.get(index);
	}
	
	
	
	
	
	public int getTotalChildren(){
		return childs.size();
	}
	public ArrayList<NodoMario> getChildren(){
		return new ArrayList<NodoMario>(childs.values());
	}
	public ArrayList<String> getChildrenInfo(){					// VIII
		ArrayList<String> result=new ArrayList<>();
		for(NodoMario nodo : getChildren())		result.add(nodo.get());
		return result;
	}
}