package mario;

public class RootAlreadyExistsException extends Exception {
	private static final long serialVersionUID = 1067485575112503193L;

	public RootAlreadyExistsException() {
		super("Attenzione! Si è tentato inserire una radice in un albero già contenente una radice.");
	}
}
