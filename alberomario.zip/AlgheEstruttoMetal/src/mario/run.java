package mario;

public class run {
	public static void main(String[] args) throws RootAlreadyExistsException, OverWriteException, ChildDoesntExistException {

		AlberoMario comunismo = new AlberoMario(3);
		NodoMario tmp;
		comunismo.insertRoot("GIGIONE");
		comunismo.debug();
		comunismo.replaceRoot("Berlusca, Cavaliere", 0);
		comunismo.debug();

		tmp=comunismo.getRoot();
		comunismo.insertNode(tmp,"RomanoProdi, difensore della Patria", 1);
		comunismo.debug();
		tmp=comunismo.getRoot().getChild(0);
		tmp.debug();
		
		comunismo.insertNode(tmp,"DANTE",0);
		comunismo.insertNode(tmp,"BOCCACCIO",1);
		comunismo.insertNode(tmp,"DIPRE'",2);
		
		comunismo.debug();
		
		comunismo.insertNode(tmp.getChild(1), "Bucchin", 0);
		comunismo.insertNode(tmp.getChild(1), "dituma", 1);
		
		comunismo.debug();
		
		tmp=comunismo.getRoot().getChild(1);
		tmp.debug();
		comunismo.insertNode(tmp, "Peroni Mista Azzurra", 0);
		comunismo.insertNode(tmp, "Barbie Brigate Rosse", 1);
		comunismo.insertNode(tmp, "Super Mario Rave", 2);
		
		comunismo.insertNode(tmp.getChild(1),"Spettro del Comunismo",0);
		
		
		comunismo.debug();

	}		
}
