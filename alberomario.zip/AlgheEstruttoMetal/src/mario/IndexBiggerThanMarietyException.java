package mario;

public class IndexBiggerThanMarietyException extends Exception {

}
